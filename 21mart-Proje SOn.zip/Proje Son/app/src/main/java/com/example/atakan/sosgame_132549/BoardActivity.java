package com.example.atakan.sosgame_132549;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class BoardActivity extends Activity {
    public String playso = "S";
    public int r = 0;
public int playerTurn=1;

   public  int p1sc = 0;
  public   int p2sc = 0;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_board);

        Toast.makeText(this, "S selected", Toast.LENGTH_SHORT).show();

        // POPUP MENU BUTTON CLICKED GENERATE POPUP MENU


        Button popmenubtn = (Button) findViewById(R.id.popmenubutton);
        popmenubtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(BoardActivity.this, popupmenu.class));
            }
        });


    }


    public void insertSOS(View view) {

        // shows popup menu when all buttons are clicked.

        r += 1;
        if (r >= 49) {
            Toast.makeText(this, "Game Finished", Toast.LENGTH_LONG).show();
            Intent i = new Intent(this, popupmenu.class);
            startActivity(i);


        }
        Button btn = (Button) findViewById(view.getId());
        btn.setText(playso);
        btn.setEnabled(false);


        checkSOS(btn);
        changeTurn();

    }

    public void setS(View view) {
        Button Sbtn=(Button)findViewById(R.id.buttonS);
        Button Obtn=(Button)findViewById(R.id.buttonO);
        playso = "S";
        Sbtn.setBackgroundColor(Color.RED);
        Obtn.setBackgroundColor(Color.WHITE);

    }

    public void setO(View view) {
        Button Sbtn=(Button)findViewById(R.id.buttonS);
        Button Obtn=(Button)findViewById(R.id.buttonO);

        Obtn.setBackgroundColor(Color.RED);
        Sbtn.setBackgroundColor(Color.WHITE);
        playso = "O";

    }

    //Method for checking if SOS sequence
    //*********

    public void checkSOS(View v) {

        String[] btString;
        btString = new String[49];
        Button[] buttons;
        buttons = new Button[49];
        for (int i = 0; i < buttons.length; i++) {
            {
                String buttonID = "btn" + (i + 1);

                int resID = getResources().getIdentifier(buttonID, "id", getPackageName());
                buttons[i] = ((Button) findViewById(resID));
                btString[i] = buttons[i].getText().toString();

            }
        }

        ArrayList a  = new ArrayList();

        TextView playersc = (TextView) findViewById(R.id.p1score);
        TextView player2sc=(TextView)findViewById(R.id.p2score);

        for (int i = 0; i < buttons.length; i++) {
            if(v.getId()==buttons[i].getId()){

                if(btString[i].contains("S")){


                    if(i>=16){
                    if(btString[i-8].contains("O")&&btString[i-16].contains("S")){
                        if (playerTurn==1){
                            p1sc += 1;
                            playersc.setText("" + p1sc);}
                        if (playerTurn==2){
                            p2sc += 1;
                            player2sc.setText("" + p2sc);
                        }

                    }}



                    if(i>=2){
                    if(btString[i-1].contains("O")&&btString[i-2].contains("S")){
                        if (playerTurn==1){
                            p1sc += 1;
                            playersc.setText("" + p1sc);}
                        if (playerTurn==2){
                            p2sc += 1;
                            player2sc.setText("" + p2sc);
                        }

                    }}

                    if(i<=34){
                    if(btString[i+6].contains("O")&&btString[i+12].contains("S")){
                        if (playerTurn==1){
                            p1sc += 1;
                            playersc.setText("" + p1sc);}
                        if (playerTurn==2){
                            p2sc += 1;
                            player2sc.setText("" + p2sc);
                        }

                    }}


                    if(i<=34){
                    if(btString[i+7].contains("O")&&btString[i+14].contains("S")){
                        if (playerTurn==1){
                            p1sc += 1;
                            playersc.setText("" + p1sc);}
                        if (playerTurn==2){
                            p2sc += 1;
                            player2sc.setText("" + p2sc);
                        }

                    }}


                    if(i<=32){

                    if(btString[i+8].contains("O")&&btString[i+16].contains("S")){
                        if (playerTurn==1){
                            p1sc += 1;
                            playersc.setText("" + p1sc);}
                        if (playerTurn==2){
                            p2sc += 1;
                            player2sc.setText("" + p2sc);
                        }

                    }}

                    if(i<=46){
                    if(btString[i+1].contains("O")&&btString[i+2].contains("S")){
                        if (playerTurn==1){
                            p1sc += 1;
                            playersc.setText("" + p1sc);}
                        if (playerTurn==2){
                            p2sc += 1;
                            player2sc.setText("" + p2sc);
                        }

                    }}

                    if(i>=14){
                    if(btString[i-6].contains("O")&&btString[i-12].contains("S")){
                        if (playerTurn==1){
                            p1sc += 1;
                            playersc.setText("" + p1sc);}
                        if (playerTurn==2){
                            p2sc += 1;
                            player2sc.setText("" + p2sc);
                        }

                    }}

                    if(i>=14){
                    if(btString[i-7].contains("O")&&btString[i-14].contains("S")){
                        if (playerTurn==1){
                            p1sc += 1;
                            playersc.setText("" + p1sc);}
                        if (playerTurn==2){
                            p2sc += 1;
                            player2sc.setText("" + p2sc);
                        }

                    }}



                }
                if(btString[i].contains("O")) {


                    if(i>=1){
                    if(btString[i-1].contains("S")&&btString[i+1].contains("S")){
                        if (playerTurn==1){
                            p1sc += 1;
                            playersc.setText("" + p1sc);}
                        if (playerTurn==2){
                            p2sc += 1;
                            player2sc.setText("" + p2sc);
                        }

                    }}


                    if(i>=7){
                    if(btString[i-7].contains("S")&&btString[i+7].contains("S")){
                        if (playerTurn==1){
                            p1sc += 1;
                            playersc.setText("" + p1sc);}
                        if (playerTurn==2){
                            p2sc += 1;
                            player2sc.setText("" + p2sc);
                        }

                    }}





                    if(i>=8){
                    if(btString[i-8].contains("S")&&btString[i+8].contains("S")){
                        if (playerTurn==1){
                            p1sc += 1;
                            playersc.setText("" + p1sc);}
                        if (playerTurn==2){
                            p2sc += 1;
                            player2sc.setText("" + p2sc);
                        }

                    }}
                    if(i>=8){
                    if(btString[i-6].contains("S")&&btString[i+6].contains("S")){
                        if (playerTurn==1){
                            p1sc += 1;
                            playersc.setText("" + p1sc);}
                        if (playerTurn==2){
                            p2sc += 1;
                            player2sc.setText("" + p2sc);
                        }

                    }}






                }






            }























//            if (i <= 46) {
//
//                if (btString[i].contains("S") && btString[i + 1].contains("O") && btString[i + 2].contains("S") && i != 5 && i != 6 && i != 12 && i != 13 && i != 19 && i != 20 && i != 26 && i != 27 && i != 33 && i != 34 && i != 40 && i != 41) {
//
//                        if (playerTurn==1){
//                        p1sc += 1;
//                        playersc.setText("" + p1sc);}
//                        if (playerTurn==2){
//                            p2sc += 1;
//                            player2sc.setText("" + p2sc);
//                        }
//
//                }// if statement for horizontal
//
//
//
//
//
//
//
//
//
//
//                if (i <= 32) {
//                    if (btString[i].contains("S") && btString[i + 8].contains("O") && btString[i + 16].contains("S") && i != 5 && i != 6 && i != 12 && i != 13 && i != 19 && i != 20 && i != 26 && i != 27 && i != 33 && i != 34 && i != 40 && i != 41) {
//                        if (playerTurn==1){
//                            p1sc += 1;
//                            playersc.setText("" + p1sc);}
//                        if (playerTurn==2){
//                            p2sc += 1;
//                            player2sc.setText("" + p2sc);
//                        }
//                    }
//                } // if statemen for diagonal left to right
//
//
//
//
//
//
//
//
//
//
//
//
//                if (i <= 34) {
//                    if (btString[i].contains("S") && btString[i + 7].contains("O") && btString[i + 14].contains("S")) {
//                        if (playerTurn==1){
//                            p1sc += 1;
//                            playersc.setText("" + p1sc);}
//                        if (playerTurn==2){
//                            p2sc += 1;
//                            player2sc.setText("" + p2sc);
//                        }
//                    }
//                }// if statement for vertical
//
//
//
//
//
//
//
//
//
//                if (i <= 36) {
//                    if (btString[i].contains("S") && btString[i + 6].contains("O") && btString[i + 12].contains("S")&& i != 0&& i != 1&& i != 7&& i != 8&& i != 14&& i != 15&& i != 21&& i != 22&& i != 28&& i != 29) {
//                        if (playerTurn==1){
//                            p1sc += 1;
//                            playersc.setText("" + p1sc);}
//                        if (playerTurn==2){
//                            p2sc += 1;
//                            player2sc.setText("" + p2sc);
//                        }
//                    }
//                }// if statement for diagonal right to left
//
//
//            }

        } //FOr loop


    }




    public void changeTurn(){
        if(playerTurn==1){
            playerTurn=2;
        }
        else{
            playerTurn=1;
                            }
    }


} //Activity






