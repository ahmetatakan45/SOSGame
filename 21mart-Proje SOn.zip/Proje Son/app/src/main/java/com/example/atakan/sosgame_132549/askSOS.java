package com.example.atakan.sosgame_132549;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;

public class askSOS extends Activity {

    public String Sos="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_ask_sos);

        DisplayMetrics AskSOS = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(AskSOS);
        int MenuWidth = AskSOS.widthPixels;
        int MenuHeight = AskSOS.heightPixels;
        getWindow().setLayout((int) (MenuWidth * .8), (int) (MenuHeight * .2));
    }

    public void selectS(View view) {

            Intent mIntent = getIntent();
            int intValue = mIntent.getIntExtra("Button", 0);


                if(intValue == R.id.btn1){
                    Toast.makeText(this,"select S",Toast.LENGTH_SHORT).show();

// Button btn11=(Button)findViewById(R.id.btn1);
////
//                    btn11.setText("S");
                    finish();






            }






//            Sos+="S";
//            SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
//            SharedPreferences.Editor editor = prefs.edit();
//            editor.putString("string_id", Sos); //InputString: from the EditText
//            editor.commit();
//            finish();
        }


// Bundle b = new Bundle();
//        b.putString("id", Sos);
//        BoardActivity pv = new BoardActivity();
        //     Intent i = new Intent(this, BoardActivity.class);
//       i.putExtra("select", "S");
//     i.putExtra("yourcode", "code");

//        Bundle bundle=new Bundle();
//        bundle.putString("let","S");
//        i.putExtras(bundle);


    public void selectO(View view) {

            Sos+="O";
            SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
            SharedPreferences.Editor editor = prefs.edit();
            editor.putString("string_id", Sos); //InputString: from the EditText
            editor.commit();
            finish();


    }
}
