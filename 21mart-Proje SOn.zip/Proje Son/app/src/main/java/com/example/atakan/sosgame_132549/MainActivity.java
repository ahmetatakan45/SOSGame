package com.example.atakan.sosgame_132549;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.TextView;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);// Title Bar removal
        setContentView(R.layout.activity_main);



        // Exit button clicked terminate the application

        TextView exitbutton=(TextView)findViewById(R.id.menuExit);
        exitbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();

            }
        });
    }



    // Go to board activity
    public void createBoardpvp(View view){
        Intent createBoard=new Intent(this,BoardActivity.class);
        startActivity(createBoard);
    }
}
