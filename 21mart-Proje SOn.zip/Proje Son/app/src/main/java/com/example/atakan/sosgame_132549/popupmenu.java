package com.example.atakan.sosgame_132549;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;

public class popupmenu extends Activity{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_popupmenu);


        // DETERMINE THE METRICS OF THE POPUP MENU
        DisplayMetrics popupmenu=new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(popupmenu);
        int MenuWidth=popupmenu.widthPixels;
        int MenuHeight=popupmenu.heightPixels;
        getWindow().setLayout((int)(MenuWidth*.7),(int)(MenuHeight*.3));
    }


    //BUTTON TO CONTINUE GAME
    public void continueGame(View view){
       popupmenu.this.finish();
    }
    //ON CLICK TERMINATE ALL OPENED ACTIVITES AND START NEW ACTIVITY TO MAIN MENU
    public void turnMainMenu(View view) {
        Intent intentMainMenu=new Intent(getApplicationContext(),MainActivity.class);
        intentMainMenu.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intentMainMenu);
        popupmenu.this.finish();



    }
    // Restarts the game p v p
    public void restartGame(View view){
        Intent i=new Intent(getApplicationContext(),BoardActivity.class);
        startActivity(i);



    }
}
